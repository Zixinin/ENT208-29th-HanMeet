/// @DnDAction : YoYo Games.Common.Function
/// @DnDVersion : 1
/// @DnDHash : 5DCBE386
/// @DnDComment : 
/// @DnDArgument : "funcName" "Scr_newplayer_master"
function Scr_newplayer_master() {}